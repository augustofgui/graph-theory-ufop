#include "DFS.h"

int main()
{      
    int numVert;
    int numArcs;
    int isDir;
    int initialVert;

    int i, s, d, w;

    scanf("%d %d %d %d", &numVert, &numArcs, &isDir, &initialVert);

    Graph* graph = createGraph(numVert);

    for( i=0; i < numArcs; i++) {
        scanf("%d %d %d", &s, &d, &w);
        addEdge(graph, s, d, w);
    }

    printGraph(graph);
    
    doDFS(graph, initialVert);
    
    return 0;
}