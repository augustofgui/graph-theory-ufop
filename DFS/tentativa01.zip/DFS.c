#include "DFS.h"

Node *createNode(int vId)
{
    Node *newNode = malloc(sizeof(Node));
    newNode->vertex = vId;
    newNode->next = NULL;
    return newNode;
}

Graph *createGraph(int numVertices)
{
    Graph *newGraph = malloc(sizeof(Graph));
    newGraph->numVertices = numVertices;

    newGraph->adjLists = malloc(numVertices * sizeof(Node *));

    int i;
    for (i = 0; i < numVertices; i++)
        newGraph->adjLists[i] = NULL;

    return newGraph;
}

void addEdge(Graph *graph, int s, int d, int peso)
{
    // Add edge from s to d
    Node *newNode = createNode(d-1);

    if(graph->adjLists[s-1] == NULL) {
        newNode->next = graph->adjLists[s-1];
        graph->adjLists[s-1] = newNode;
        return;
    }

    Node *temp = graph->adjLists[s-1];
    while (temp->next != NULL)
        temp = temp->next;

    temp->next = newNode;
}

void printGraph(Graph *graph)
{
    int v;

    for (v = 0; v < graph->numVertices; v++)
    {
        Node *temp = graph->adjLists[v];
        printf("\n Vertex %d\n: ", v+1);
        while (temp)
        {
            printf("%d -> ", temp->vertex+1);
            temp = temp->next;
        }
        printf("\n");
    }

    printf("\n");
}

void doDFS(Graph *graph, int vertex)
{
    bool *marked = calloc(graph->numVertices, sizeof(bool));

    dfs(graph, vertex-1, marked);
}

void dfs(Graph *graph, int vertex, bool *marked)
{
    int v;  
    if(marked[vertex] == true)
        return;
    
    Node *temp = graph->adjLists[vertex];
    visit(vertex, marked);

    while (temp != NULL)
    {   
        //printf("%d:%d:%s\n", v+1, temp->vertex+1, marked[temp->vertex] ? "true" : "false");
        if (marked[temp->vertex] != true)
            dfs(graph, temp->vertex, marked);

        temp = temp->next;
    }
}

void visit(int vId, bool * marked)
{
    printf("%d\n", vId+1);
    marked[vId] = true;
}